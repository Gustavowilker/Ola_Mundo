function mudarCor(color){
    document.body.style.background = color;

    }
